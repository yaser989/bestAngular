import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppSettings } from 'src/app/settings/app.sittings';
import {Character} from 'src/app/models/character';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CharacterService {

  constructor(private http : HttpClient) { }

finAllCaracter(){
  return this.http.get<Character>(AppSettings.App_URL + "/caracter/")
}

findAllUserCharacters(idUser: number){
return this.http.get<Character[]>(AppSettings.App_URL+"/caracter/all/"+idUser);
}
findCaracterById(idCaracter : number){
return this.http.get<Character>(AppSettings.App_URL +"/caracter/" +idCaracter )
}

saveCaracter(character : Character, idUser : number) : Observable<any>{
return this.http.post<Character>(AppSettings.App_URL + "/caracter/create/"+idUser, character);
}

shareCharacter(idCaracter : number, isShared : boolean ){
  return this.http.get<Character>(AppSettings.App_URL + "/caracter/share/" + idCaracter + "/" + isShared);
}

deleteCharacter (idCaracter: number): Observable<any>{
  return this.http.delete<Character>(AppSettings.App_URL + "/caracter/" + idCaracter);
}
updateCaracter(character : Character, idCaracter : number) : Observable<any>{
  return this.http.put<Character>(AppSettings.App_URL + "/caracter/update/"+idCaracter, character);
}

}
