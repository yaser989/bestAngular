import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { AppSettings } from 'src/app/settings/app.sittings';
import { User } from 'src/app/models/user';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  findAllUser(){
    return this.http.get<User>(AppSettings.App_URL + "/user/" )
  }

  findUserById(idUser : number){
    return this.http.get<User>(AppSettings.App_URL + "/user/" + idUser)
  }

  saveUser(user : User){
    return this.http.post<User>(AppSettings.App_URL + "/user/" , user)
  }

  login(mail: string, password: string)  {
    return this.http.post<User>(AppSettings.App_URL + "/user/login?mail=" + mail + "&password=" + password,null);
  }
}
