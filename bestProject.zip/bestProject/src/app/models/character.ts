export class Character{
    idCaracter: number;
    name: string;
    category: string;
    strength: string;
    shared: boolean;
    idOwner : number;
    legend : string;
    idUser : number;
    photo : File;
}