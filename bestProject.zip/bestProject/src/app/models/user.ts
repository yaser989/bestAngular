export class User{
    idUser: number;
    firstName: string;
    lastName: string;
    mail: string;
    password: string;
}