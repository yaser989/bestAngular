import { Component, OnInit } from '@angular/core';
import { Character } from 'src/app/models/character';
import { CharacterService } from 'src/app/services/character/character.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-chaeacter',
  templateUrl: './update-chaeacter.component.html',
  styleUrls: ['./update-chaeacter.component.css']
})
export class UpdateChaeacterComponent implements OnInit {

  character : Character = new Character();
  idCaracter : number;
  constructor(private characterService : CharacterService, private route : ActivatedRoute, private router: Router) { 

  }

  ngOnInit() {

    this.idCaracter = this.route.snapshot.params.idCaracter;
    this.characterService.findCaracterById(this.idCaracter)
    .subscribe(data => {
      this.character = data
      console.log(this.character);
    });

  }
  updateCaracter() {
    this.characterService.updateCaracter(this.character, this.idCaracter).subscribe(data => {
      this.character = data;
      this.router.navigate(['/home']);

    })
  }

}
