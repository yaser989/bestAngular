import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateChaeacterComponent } from './update-chaeacter.component';

describe('UpdateChaeacterComponent', () => {
  let component: UpdateChaeacterComponent;
  let fixture: ComponentFixture<UpdateChaeacterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateChaeacterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateChaeacterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
