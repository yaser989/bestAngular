import { Component, OnInit } from '@angular/core';
import { CharacterService } from 'src/app/services/character/character.service';
import { User } from 'src/app/models/user';
import { Router } from '@angular/router';
import { Character } from 'src/app/models/character';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {UserService} from 'src/app/services/user/user.service'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  user : User;
  animeCharacters : Character[];
  errorMessage : string;
  successMessage : string;
  
  constructor(private characterService: CharacterService, private router : Router, private userServic :UserService ) { 
    this.checkUser();
  }

  ngOnInit() {
 this.findAllCharacters();
}

  findAllCharacters(){
    this.characterService.findAllUserCharacters(this.user.idUser)
    .pipe()
    .subscribe(data => {
      this.animeCharacters = data;
       }, error =>{
         console.log(error);
 });

  }

  checkUser(){
    if (localStorage.getItem('currentUser') === undefined || localStorage.getItem('currentUser') === null){
      this.router.navigate(['/login']);
      return;
    }
    this.user = JSON.parse(localStorage.getItem('currentUser'));
  }

  shareCharacter(idCaracter : number, shared : boolean){

      if(idCaracter === undefined){
       this.displayMessage("An error has occured while sharing the character",2);
      }
     this.characterService.shareCharacter(idCaracter,shared)
     .pipe()
     .subscribe(data => {
       this.displayMessage("character was succsefully updated ",1);
       this.findAllCharacters();
     });

  }

  displayMessage(msg : string, type : number){

    if (type === 1){
      this.successMessage = msg;
      setTimeout (() => {this.successMessage = ""}, 5000);
    }
    else if (type === 2){
      this.errorMessage = msg;
      setTimeout (() => {this.errorMessage = ""}, 5000);
  }
}

filter(keyWord: string) {
  if (keyWord === undefined || keyWord.length === 0) {
    this.findAllCharacters();
    return;
  }
  this.animeCharacters = this.animeCharacters.filter(character => 
    character.category.toLowerCase().includes(keyWord) || character.legend.toLowerCase().includes(keyWord) || 
    character.name.toLowerCase().includes(keyWord) 
  );
}

removeCharacter(idCaracter : number){
  if (idCaracter === undefined){
    this.displayMessage("An error has occured while removing the character", 2);
    return;
  }
  if(confirm("Do you relly want to remove the character")){
    this.characterService.deleteCharacter(idCaracter)
    .subscribe(data => this.findAllCharacters = data, x => this.displayMessage("Character succfully removed", 1));
  }
  window.location.reload();
}

addNewItem(){
  let idUser = localStorage.getItem('currentUser');
  this.characterService.findAllUserCharacters(this.user.idUser)
  .subscribe(data => this.user.idUser, err => console.log(err));
  this.router.navigate(['/createNewItem']);
}

signOutUser(){
   this.router.navigate(['/login']);
}

updateCharacter(idCaracter : number){
  this.router.navigate(['/updateCharacter',idCaracter]);
}

}




