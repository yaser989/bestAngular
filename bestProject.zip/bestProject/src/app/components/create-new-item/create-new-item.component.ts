import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms';
import{CharacterService} from 'src/app/services/character/character.service';
import { Router } from '@angular/router'; 
import { User } from 'src/app/models/user';
import {Character} from 'src/app/models/character';

@Component({
  selector: 'app-create-new-item',
  templateUrl: './create-new-item.component.html',
  styleUrls: ['./create-new-item.component.css']
})
export class CreateNewItemComponent implements OnInit {
  characterForm : FormGroup;
  user : User = new User();
  caracter : Character = new Character();
  selectedFile: any;

  constructor(private characterService : CharacterService, private router : Router ) {
    this.checkUser();
   }

  ngOnInit() {
    this.characterForm= new FormGroup({
      name : new FormControl ('',Validators.required),
      category : new FormControl ('', Validators.required),
      legend : new FormControl ('',Validators.required)
    });

  }

  
  checkUser(){
    if (localStorage.getItem('currentUser') === undefined || localStorage.getItem('currentUser') === null){
      this.router.navigate(['/login']);
      return;
    }
    this.user = JSON.parse(localStorage.getItem('currentUser'));
  }

  createCharacter(){
    this.characterService.saveCaracter(this.caracter,this.user.idUser).subscribe(data => {
      this.caracter = data
      console.log(this.caracter)
      console.log(this.user.idUser)
    });
    this.router.navigate(['/home']);
  }

}
