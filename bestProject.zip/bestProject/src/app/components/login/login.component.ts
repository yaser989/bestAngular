import { Component, OnInit } from '@angular/core';
import{FormGroup, FormBuilder, Validators, FormControl} from '@angular/forms';
import { UserService } from 'src/app/services/user/user.service';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

  errorMessage : string;
  private loginForm: FormGroup;
  constructor(private userServic : UserService,private formBuilder: FormBuilder,private router :Router) { 
    this.loginForm=new FormGroup({
      login : new FormControl ('',Validators.required),
      password :new FormControl ('',Validators.required)
    });
  }

 

  ngOnInit() {
  }


  loginUser() {
    this.errorMessage = "";
    if (this.loginForm.invalid) {
      this.errorMessage = "EMail and / or password is incorrect";
      return;
    }
    this.userServic.login(this.login.value, this.password.value)
      .pipe()
      .subscribe(data => {
        localStorage.setItem('currentUser', JSON.stringify(data));
        console.log(data);
        
        this.router.navigate(['/home']);
      }, error => {
        if(error.status === 404) {
          this.errorMessage = "No user was found with the following Email/Password";
        }
        if(error.status === 400) {
          this.errorMessage = "EMail and / or password is incorrect";
        }
      });
  }

  get login() {
    return this.loginForm.get('login');
  }

  get password() {
    return this.loginForm.get('password');
  }
     
  }



