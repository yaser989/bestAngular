export class AppSettings{
    public static App_URL = "http://localhost:8080/v1";
}