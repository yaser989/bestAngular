import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './components/login/login.component';
import { SubscribeComponent } from './components/subscribe/subscribe.component';
import { HomeComponent } from './components/home/home.component';
import { CreateNewItemComponent } from './components/create-new-item/create-new-item.component';
import { UpdateChaeacterComponent } from './components/update-chaeacter/update-chaeacter.component';


const routes: Routes = [

{path: 'login', component : LoginComponent},
{path: 'subscribe', component: SubscribeComponent},
{path: 'home', component: HomeComponent},
{path: 'createNewItem', component:CreateNewItemComponent},
{path: 'updateCharacter/:idCaracter',component:UpdateChaeacterComponent},
{path : '', redirectTo:'/login', pathMatch:'full' }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
